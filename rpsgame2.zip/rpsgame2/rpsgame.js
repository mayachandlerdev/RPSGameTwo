let botScore = 0;
let playerScore = 0;
let playerOptions = ['Rock', 'Paper', 'Scissor', 'Lizard', 'Spock'];
let botsChoice = ['Rock', 'Paper', 'Scissor', 'Lizard', 'Spock'];
let rock = document.getElementById("rock");
let pap = document.getElementById("pap");
let cut = document.getElementById("cut");
let randomanswer = document.getElementById("randomanswer")
let random = botsChoice[Math.floor(Math.random() * botsChoice.length)];



//score function
function whoIsWinner (botScore, playerScore){
    if (botScore > playerScore){
        return 'Bot Wins'
    }else{
        return 'Player Wins'
    }
}

//show bot choice
    randomanswer.addEventListener('Click', function(){
        random = botsChoice[Math.floor(Math.random() * botsChoice.length)];
        h2 = document.getElementById("botAnswer");
        h2.appendChild(random);
})

//display playerChoice

//rock
    rock.addEventListener('click', function(){
        var answer1 = document.createTextNode(playerOptions[0]),
         h2 = document.getElementById("playerAnswer");
         h2.appendChild(answer1);
    })


//paper
    pap.addEventListener('click', function(){
        var answer2 = document.createTextNode(playerOptions[1]),
        h2 = document.getElementById("playerAnswer");
        h2.appendChild(answer2);
    })

//cut

    cut.addEventListener('click', function(){
        var answer3 = document.createTextNode(playerOptions[2]),
        h2 = document.getElementById("playerAnswer");
        h2.appendChild(answer3);        
    })

        //need to improve on displaying stuff in the dom

        //sometimes i do things more than once in different ways and it trips me up, i think i need more when in reality i have enough 